# `@alicloud/ros-cdk-assembly-schema`

> TODO: description

## Usage

```
const rosAssemblySchema = require('@alicloud/ros-cdk-assembly-schema');

// TODO: DEMONSTRATE API
```
